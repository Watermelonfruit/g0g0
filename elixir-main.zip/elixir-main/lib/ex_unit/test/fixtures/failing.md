# Example

    iex> 1 + 2
    4
